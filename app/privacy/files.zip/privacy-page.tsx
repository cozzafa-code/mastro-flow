// app/privacy/page.tsx
// ═══════════════════════════════════════════════════════════
// MASTRO ERP — Privacy Policy
// Conforme GDPR (UE) 2016/679 — Aggiornata marzo 2026
// ═══════════════════════════════════════════════════════════

export const metadata = {
  title: "Privacy Policy — MASTRO ERP",
  description: "Informativa sul trattamento dei dati personali ai sensi del GDPR (UE) 2016/679",
};

export default function PrivacyPage() {
  return (
    <div style={{ minHeight: "100vh", background: "#F2F1EC", fontFamily: "'Inter', -apple-system, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "#1A1A1C", padding: "20px 24px", display: "flex", alignItems: "center", gap: 12 }}>
        <a href="/" style={{ textDecoration: "none" }}>
          <div style={{ fontSize: 20, fontWeight: 900, color: "#fff", letterSpacing: -0.5 }}>MASTRO</div>
        </a>
        <div style={{ fontSize: 12, color: "#888", marginLeft: 4 }}>/ Privacy Policy</div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 760, margin: "0 auto", padding: "40px 24px 80px" }}>
        <div style={{ background: "#fff", borderRadius: 16, padding: "40px 40px", boxShadow: "0 2px 16px rgba(0,0,0,0.06)" }}>

          <h1 style={{ fontSize: 28, fontWeight: 900, color: "#1A1A1C", marginBottom: 4, marginTop: 0 }}>
            Privacy Policy
          </h1>
          <p style={{ color: "#888", fontSize: 13, marginBottom: 32, marginTop: 0 }}>
            Ultima modifica: marzo 2026 — Versione 1.0
          </p>

          <Section title="1. Titolare del Trattamento">
            <p>
              Il titolare del trattamento dei dati personali è <strong>Galassia Mastro ApS</strong>,
              con sede legale in Danimarca (Odense), raggiungibile all'indirizzo email:{" "}
              <a href="mailto:privacy@mastro-erp.com" style={linkStyle}>privacy@mastro-erp.com</a>.
            </p>
            <p>
              Per qualsiasi questione relativa al trattamento dei tuoi dati personali puoi contattarci
              a questo indirizzo in qualsiasi momento.
            </p>
          </Section>

          <Section title="2. Dati Raccolti">
            <p>Raccogliamo le seguenti categorie di dati personali:</p>
            <ul style={ulStyle}>
              <li><strong>Dati di registrazione:</strong> nome, cognome, indirizzo email, password (cifrata), ragione sociale, partita IVA, telefono, settore di attività.</li>
              <li><strong>Dati di utilizzo:</strong> commesse create, clienti inseriti, misure, preventivi, fatture, ordini fornitore — tutti i dati operativi che inserisci nel gestionale.</li>
              <li><strong>Dati tecnici:</strong> indirizzo IP, tipo di browser, sistema operativo, pagine visitate, durata della sessione, log di accesso.</li>
              <li><strong>Dati di pagamento:</strong> gestiti interamente da Stripe Inc. Non conserviamo dati di carte di credito o coordinate bancarie.</li>
              <li><strong>Consenso GDPR:</strong> data e ora dell'accettazione della presente informativa, preferenza marketing.</li>
            </ul>
          </Section>

          <Section title="3. Finalità e Base Giuridica del Trattamento">
            <table style={tableStyle}>
              <thead>
                <tr style={{ background: "#F2F1EC" }}>
                  <th style={thStyle}>Finalità</th>
                  <th style={thStyle}>Base giuridica (GDPR Art. 6)</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Fornitura del servizio MASTRO ERP", "Esecuzione del contratto (Art. 6.1.b)"],
                  ["Gestione dell'account e autenticazione", "Esecuzione del contratto (Art. 6.1.b)"],
                  ["Fatturazione e adempimenti fiscali", "Obbligo legale (Art. 6.1.c)"],
                  ["Sicurezza e prevenzione frodi", "Legittimo interesse (Art. 6.1.f)"],
                  ["Supporto tecnico e assistenza clienti", "Esecuzione del contratto (Art. 6.1.b)"],
                  ["Miglioramento del servizio (analytics anonime)", "Legittimo interesse (Art. 6.1.f)"],
                  ["Comunicazioni commerciali e aggiornamenti", "Consenso esplicito (Art. 6.1.a)"],
                  ["Adempimento obblighi GDPR (log consenso)", "Obbligo legale (Art. 6.1.c)"],
                ].map(([fin, base], i) => (
                  <tr key={i} style={{ borderBottom: "1px solid #F2F1EC" }}>
                    <td style={tdStyle}>{fin}</td>
                    <td style={{ ...tdStyle, color: "#2D7A6B", fontSize: 12 }}>{base}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Section>

          <Section title="4. Conservazione dei Dati">
            <ul style={ulStyle}>
              <li><strong>Dati account e operativi:</strong> conservati per tutta la durata del contratto e per 10 anni successivi per obblighi fiscali.</li>
              <li><strong>Log tecnici:</strong> 90 giorni.</li>
              <li><strong>Dati di marketing:</strong> fino alla revoca del consenso.</li>
              <li><strong>Log cancellazione GDPR:</strong> conservati per 5 anni per obblighi di compliance.</li>
            </ul>
            <p>
              In caso di cancellazione dell'account, tutti i dati operativi vengono eliminati entro 30 giorni,
              salvo obblighi di legge.
            </p>
          </Section>

          <Section title="5. Condivisione dei Dati">
            <p>Non vendiamo i tuoi dati personali a terzi. I dati possono essere condivisi con:</p>
            <ul style={ulStyle}>
              <li><strong>Supabase Inc.</strong> (USA) — database e autenticazione. Trasferimento dati extra-UE coperto da Standard Contractual Clauses.</li>
              <li><strong>Vercel Inc.</strong> (USA) — hosting e CDN. Trasferimento coperto da SCCs.</li>
              <li><strong>Stripe Inc.</strong> (USA) — pagamenti. Certificato PCI DSS Level 1.</li>
              <li><strong>Autorità competenti</strong> — solo se richiesto da obblighi di legge o ordini giudiziari.</li>
            </ul>
          </Section>

          <Section title="6. I Tuoi Diritti (GDPR Art. 15-22)">
            <p>Hai il diritto di:</p>
            <ul style={ulStyle}>
              <li><strong>Accesso (Art. 15):</strong> ottenere copia dei tuoi dati personali.</li>
              <li><strong>Rettifica (Art. 16):</strong> correggere dati inesatti o incompleti.</li>
              <li><strong>Cancellazione (Art. 17):</strong> chiedere l'eliminazione dei tuoi dati. Puoi farlo direttamente da <em>Impostazioni → Generali → Elimina account</em>.</li>
              <li><strong>Limitazione (Art. 18):</strong> limitare il trattamento in determinate circostanze.</li>
              <li><strong>Portabilità (Art. 20):</strong> ricevere i tuoi dati in formato strutturato e leggibile da macchina.</li>
              <li><strong>Opposizione (Art. 21):</strong> opporti al trattamento basato su legittimo interesse.</li>
              <li><strong>Revoca del consenso:</strong> puoi revocare il consenso al marketing in qualsiasi momento da Impostazioni.</li>
            </ul>
            <p>
              Per esercitare questi diritti scrivi a{" "}
              <a href="mailto:privacy@mastro-erp.com" style={linkStyle}>privacy@mastro-erp.com</a>.
              Risponderemo entro 30 giorni. Hai anche il diritto di proporre reclamo al Garante per la
              Protezione dei Dati Personali (<a href="https://www.garanteprivacy.it" target="_blank" rel="noopener noreferrer" style={linkStyle}>garanteprivacy.it</a>).
            </p>
          </Section>

          <Section title="7. Cookie e Tecnologie di Tracciamento">
            <p>
              MASTRO ERP utilizza esclusivamente cookie tecnici essenziali per il funzionamento del servizio
              (autenticazione, sessione). Non utilizziamo cookie di profilazione o cookie di terze parti
              a scopo pubblicitario.
            </p>
            <ul style={ulStyle}>
              <li><strong>Cookie di sessione:</strong> necessari per mantenere l'accesso autenticato. Durata: sessione.</li>
              <li><strong>LocalStorage:</strong> utilizzato per preferenze UI (tema, impostazioni). Nessun dato personale.</li>
            </ul>
          </Section>

          <Section title="8. Sicurezza">
            <p>
              Adottiamo misure tecniche e organizzative adeguate per proteggere i tuoi dati:
              cifratura TLS in transito, cifratura a riposo su Supabase, Row Level Security (RLS)
              su tutte le tabelle del database, autenticazione sicura tramite Supabase Auth,
              backup giornalieri automatici con point-in-time recovery.
            </p>
          </Section>

          <Section title="9. Modifiche alla Privacy Policy">
            <p>
              Ci riserviamo il diritto di aggiornare questa informativa. In caso di modifiche
              sostanziali, ti notificheremo via email con almeno 15 giorni di preavviso.
              La versione aggiornata sarà sempre disponibile su questa pagina.
            </p>
          </Section>

          <div style={{ marginTop: 40, padding: "16px 20px", background: "#F2F1EC", borderRadius: 10, fontSize: 12, color: "#888", lineHeight: 1.6 }}>
            <strong style={{ color: "#1A1A1C" }}>Galassia Mastro ApS</strong><br />
            Email: <a href="mailto:privacy@mastro-erp.com" style={linkStyle}>privacy@mastro-erp.com</a><br />
            Per richieste GDPR: <a href="mailto:privacy@mastro-erp.com" style={linkStyle}>privacy@mastro-erp.com</a>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <h2 style={{ fontSize: 16, fontWeight: 800, color: "#1A1A1C", marginBottom: 12, marginTop: 0, paddingBottom: 8, borderBottom: "2px solid #F2F1EC" }}>
        {title}
      </h2>
      <div style={{ fontSize: 14, color: "#444", lineHeight: 1.8 }}>
        {children}
      </div>
    </div>
  );
}

const linkStyle: React.CSSProperties = { color: "#2D7A6B", fontWeight: 600 };
const ulStyle: React.CSSProperties = { paddingLeft: 20, lineHeight: 2, margin: "8px 0" };
const tableStyle: React.CSSProperties = { width: "100%", borderCollapse: "collapse", fontSize: 13 };
const thStyle: React.CSSProperties = { textAlign: "left", padding: "10px 12px", fontWeight: 700, color: "#1A1A1C", fontSize: 12 };
const tdStyle: React.CSSProperties = { padding: "10px 12px", color: "#444", verticalAlign: "top" };
