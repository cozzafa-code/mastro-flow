// app/termini/page.tsx
// ═══════════════════════════════════════════════════════════
// MASTRO ERP — Termini di Servizio
// Aggiornati marzo 2026
// ═══════════════════════════════════════════════════════════

export const metadata = {
  title: "Termini di Servizio — MASTRO ERP",
  description: "Termini e condizioni di utilizzo del servizio MASTRO ERP",
};

export default function TerminiPage() {
  return (
    <div style={{ minHeight: "100vh", background: "#F2F1EC", fontFamily: "'Inter', -apple-system, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "#1A1A1C", padding: "20px 24px", display: "flex", alignItems: "center", gap: 12 }}>
        <a href="/" style={{ textDecoration: "none" }}>
          <div style={{ fontSize: 20, fontWeight: 900, color: "#fff", letterSpacing: -0.5 }}>MASTRO</div>
        </a>
        <div style={{ fontSize: 12, color: "#888", marginLeft: 4 }}>/ Termini di Servizio</div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: 760, margin: "0 auto", padding: "40px 24px 80px" }}>
        <div style={{ background: "#fff", borderRadius: 16, padding: "40px 40px", boxShadow: "0 2px 16px rgba(0,0,0,0.06)" }}>

          <h1 style={{ fontSize: 28, fontWeight: 900, color: "#1A1A1C", marginBottom: 4, marginTop: 0 }}>
            Termini di Servizio
          </h1>
          <p style={{ color: "#888", fontSize: 13, marginBottom: 32, marginTop: 0 }}>
            Ultima modifica: marzo 2026 — Versione 1.0
          </p>

          <div style={{ background: "#2D7A6B10", border: "1px solid #2D7A6B30", borderRadius: 10, padding: "14px 16px", marginBottom: 32, fontSize: 13, color: "#2D7A6B", lineHeight: 1.6 }}>
            Leggendo e accettando questi Termini, stipuli un contratto vincolante con{" "}
            <strong>Galassia Mastro ApS</strong>. Se utilizzi MASTRO ERP per conto di un'azienda,
            dichiari di avere l'autorità per vincolare l'azienda a questi Termini.
          </div>

          <Section title="1. Il Servizio">
            <p>
              <strong>MASTRO ERP</strong> è un software gestionale cloud (SaaS) per artigiani del settore
              serramentistico e affini, fornito da <strong>Galassia Mastro ApS</strong>
              (di seguito "noi", "MASTRO" o "il Fornitore").
            </p>
            <p>
              Il servizio comprende: gestione commesse, rilievi misure, preventivi, fatturazione,
              ordini fornitore, pianificazione montaggi e tutti i moduli descritti sul sito.
              Le funzionalità disponibili dipendono dal piano sottoscritto.
            </p>
          </Section>

          <Section title="2. Account e Registrazione">
            <ul style={ulStyle}>
              <li>Devi avere almeno 18 anni e la capacità legale di stipulare contratti.</li>
              <li>Sei responsabile della sicurezza delle tue credenziali di accesso.</li>
              <li>Un account è destinato a una singola azienda. L'accesso multi-utente è disponibile nei piani superiori.</li>
              <li>Non puoi cedere o trasferire il tuo account a terzi senza il nostro consenso scritto.</li>
              <li>Sei responsabile di tutte le attività svolte tramite il tuo account.</li>
            </ul>
          </Section>

          <Section title="3. Piani e Pagamenti">
            <p>
              MASTRO ERP è disponibile in diversi piani a pagamento (BASE, START, PRO, TITAN) con fatturazione mensile.
              I prezzi sono indicati sul sito e possono variare con preavviso di 30 giorni.
            </p>
            <ul style={ulStyle}>
              <li><strong>Prova gratuita:</strong> 30 giorni senza carta di credito. Al termine, è necessario sottoscrivere un piano a pagamento per continuare ad accedere ai dati.</li>
              <li><strong>Pagamento:</strong> gestito tramite Stripe. Accettiamo carte di credito/debito principali.</li>
              <li><strong>Fatturazione:</strong> mensile anticipata. Il rinnovo avviene automaticamente.</li>
              <li><strong>Disdetta:</strong> puoi disdire in qualsiasi momento. L'accesso rimane attivo fino alla fine del periodo già pagato. Nessun rimborso per frazioni di mese.</li>
              <li><strong>Mancato pagamento:</strong> dopo 7 giorni di mora l'account viene sospeso. Dopo 30 giorni i dati possono essere eliminati.</li>
            </ul>
          </Section>

          <Section title="4. Proprietà dei Dati">
            <p>
              <strong>I tuoi dati sono tuoi.</strong> Tutti i dati operativi che inserisci in MASTRO ERP
              (commesse, clienti, misure, preventivi, ecc.) rimangono di tua proprietà in ogni momento.
            </p>
            <ul style={ulStyle}>
              <li>Non utilizziamo i tuoi dati operativi per scopi diversi dalla fornitura del servizio.</li>
              <li>Puoi esportare i tuoi dati in qualsiasi momento tramite le funzioni di export.</li>
              <li>In caso di cancellazione dell'account, puoi richiedere un export completo entro 30 giorni dalla cancellazione.</li>
            </ul>
          </Section>

          <Section title="5. Uso Accettabile">
            <p>Non puoi utilizzare MASTRO ERP per:</p>
            <ul style={ulStyle}>
              <li>Attività illegali o fraudolente.</li>
              <li>Caricare contenuti che violano diritti di terzi.</li>
              <li>Tentare di accedere a dati di altri utenti o sistemi non autorizzati.</li>
              <li>Effettuare reverse engineering, decompilare o disassemblare il software.</li>
              <li>Rivendere o sublicenziare l'accesso al servizio.</li>
              <li>Inviare spam o comunicazioni non richieste tramite le funzionalità di messaggistica.</li>
            </ul>
            <p>
              Ci riserviamo il diritto di sospendere o terminare l'account in caso di violazione di questi termini,
              con o senza preavviso a seconda della gravità della violazione.
            </p>
          </Section>

          <Section title="6. Disponibilità del Servizio (SLA)">
            <ul style={ulStyle}>
              <li><strong>Uptime garantito:</strong> 99,5% mensile, escluse manutenzioni programmate.</li>
              <li><strong>Manutenzioni:</strong> comunicate con almeno 48 ore di preavviso via email, preferibilmente nelle ore notturne.</li>
              <li><strong>Supporto:</strong> risposta entro 24 ore nei giorni lavorativi (lunedì-venerdì) via email a <a href="mailto:support@mastro-erp.com" style={linkStyle}>support@mastro-erp.com</a>.</li>
              <li><strong>Status page:</strong> disponibile per monitorare lo stato del servizio in tempo reale.</li>
            </ul>
            <p>
              In caso di downtime superiore all'SLA mensile, riconosceremo un credito proporzionale
              sulla fattura successiva, su richiesta.
            </p>
          </Section>

          <Section title="7. Limitazione di Responsabilità">
            <p>
              Il servizio è fornito "così com'è" (<em>as is</em>). Nella misura massima consentita dalla legge applicabile:
            </p>
            <ul style={ulStyle}>
              <li>Non garantiamo che il servizio sia privo di errori o interruzioni.</li>
              <li>Non siamo responsabili per perdite indirette, di profitto, di dati o danni consequenziali.</li>
              <li>La nostra responsabilità totale verso di te non supera l'importo pagato negli ultimi 12 mesi.</li>
            </ul>
            <p>
              Sei responsabile di mantenere backup dei tuoi dati critici. Sebbene effettuiamo backup
              regolari, non garantiamo il recupero di dati in caso di errore dell'utente.
            </p>
          </Section>

          <Section title="8. Proprietà Intellettuale">
            <p>
              MASTRO ERP, il suo codice sorgente, design, marchi e contenuti sono di proprietà esclusiva
              di Galassia Mastro ApS e sono protetti da diritto d'autore e altre leggi sulla proprietà intellettuale.
            </p>
            <p>
              Ti concediamo una licenza limitata, non esclusiva, non trasferibile per utilizzare il servizio
              secondo questi Termini. Non acquisisci alcun diritto di proprietà sul software.
            </p>
          </Section>

          <Section title="9. Modifiche ai Termini">
            <p>
              Possiamo modificare questi Termini con preavviso di almeno 15 giorni via email per
              modifiche sostanziali. L'uso continuato del servizio dopo tale periodo costituisce
              accettazione dei nuovi Termini.
            </p>
          </Section>

          <Section title="10. Risoluzione e Cancellazione">
            <ul style={ulStyle}>
              <li><strong>Da parte tua:</strong> puoi cancellare l'account in qualsiasi momento da Impostazioni → Generali → Elimina account.</li>
              <li><strong>Da parte nostra:</strong> possiamo sospendere o terminare l'account per violazione dei Termini, con preavviso di 30 giorni salvo violazioni gravi.</li>
              <li>Alla cancellazione, i tuoi dati saranno eliminati entro 30 giorni come da Privacy Policy.</li>
            </ul>
          </Section>

          <Section title="11. Legge Applicabile e Foro Competente">
            <p>
              Questi Termini sono regolati dalla legge danese, in quanto Galassia Mastro ApS è costituita
              in Danimarca. Per i consumatori italiani, si applicano in ogni caso le norme inderogabili
              del Codice del Consumo italiano (D.Lgs. 206/2005).
            </p>
            <p>
              Per eventuali controversie, le parti tenteranno in primo luogo una risoluzione amichevole.
              In mancanza, il foro competente per i clienti italiani è quello del luogo di residenza o
              domicilio del cliente consumatore.
            </p>
          </Section>

          <Section title="12. Contatti">
            <p>
              Per qualsiasi domanda su questi Termini:<br />
              <a href="mailto:legal@mastro-erp.com" style={linkStyle}>legal@mastro-erp.com</a>
            </p>
          </Section>

          <div style={{ marginTop: 40, padding: "16px 20px", background: "#F2F1EC", borderRadius: 10, fontSize: 12, color: "#888", lineHeight: 1.6 }}>
            <strong style={{ color: "#1A1A1C" }}>Galassia Mastro ApS</strong><br />
            Odense, Danimarca<br />
            Email legale: <a href="mailto:legal@mastro-erp.com" style={linkStyle}>legal@mastro-erp.com</a><br />
            Supporto: <a href="mailto:support@mastro-erp.com" style={linkStyle}>support@mastro-erp.com</a>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <h2 style={{ fontSize: 16, fontWeight: 800, color: "#1A1A1C", marginBottom: 12, marginTop: 0, paddingBottom: 8, borderBottom: "2px solid #F2F1EC" }}>
        {title}
      </h2>
      <div style={{ fontSize: 14, color: "#444", lineHeight: 1.8 }}>
        {children}
      </div>
    </div>
  );
}

const linkStyle: React.CSSProperties = { color: "#2D7A6B", fontWeight: 600 };
const ulStyle: React.CSSProperties = { paddingLeft: 20, lineHeight: 2, margin: "8px 0" };
